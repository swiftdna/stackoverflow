const express = require('express')
const router = express.Router()

const { addTag } = require('../controllers/tagController')

router.post('/addTag', addTag)

module.exports = router
