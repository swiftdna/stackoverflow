
export const AWS_IP = 'http://localhost:'; 

export const AWS_PORT = '8081';
