export default {
  TABLET_SIZE: 980,
  MOBILE_SIZE: 640
}
