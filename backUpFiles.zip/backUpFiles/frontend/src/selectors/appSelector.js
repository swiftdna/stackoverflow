export const selectAlertFlag = (state) => state.app.alert;
export const selectToastFlag = (state) => state.app.toast;
export const selectAlertMessage = (state) => state.app.alertMessage;
export const selectAlertType = (state) => state.app.alertType;
export const selectIsLoggedIn = (state) => state.app.isLoggedIn;
export const selectUser = (state) => state.app.user;
export const selectCountries = (state) => state.app.countries;